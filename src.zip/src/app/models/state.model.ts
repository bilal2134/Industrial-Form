export interface State {
    id: string;
    name: string;
  }
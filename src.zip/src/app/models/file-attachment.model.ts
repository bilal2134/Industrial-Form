export interface FileAttachment {
    id: string;
    fileName: string;
    contentType: string;
    uploadDate: Date;
  }